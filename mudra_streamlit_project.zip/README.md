# Bharatanatyam Mudra Recognition Using CNN

## Project Overview
A deep learning application for classifying five
Bharatanatyam hand mudras using a custom CNN.

## Dataset
Kaggle: geethikanambiar/mudra-dataset

## Features
- Upload a hand mudra image
- Predict one of five mudra classes
- Display prediction confidence
- Display probabilities for all classes
- View model and dataset information

## Model
- Custom Convolutional Neural Network
- Input size: 224 x 224 x 3
- Pixel normalization: 0 to 1
- Output: Five-class Softmax

## Installation
pip install -r requirements.txt

## Run
streamlit run app.py

## Project Files
- app.py
- final_mudra_cnn.keras
- class_names.json
- requirements.txt
- README.md

## Limitations
Predictions may be less reliable under poor lighting,
occlusion, unfamiliar hand positions, or domain shift.
