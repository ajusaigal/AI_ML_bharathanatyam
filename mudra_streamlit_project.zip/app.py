
import streamlit as st
import tensorflow as tf
import numpy as np
import pandas as pd
import json
from pathlib import Path
from PIL import Image

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "final_mudra_cnn.keras"
CLASS_PATH = BASE_DIR / "class_names.json"

st.set_page_config(
    page_title="Bharatanatyam Mudra Recognition",
    page_icon="🎭",
    layout="wide"
)

@st.cache_resource
def load_resources():
    model = tf.keras.models.load_model(
        MODEL_PATH,
        compile=False
    )

    with open(CLASS_PATH, "r") as f:
        class_names = json.load(f)

    if model.output_shape[-1] != len(class_names):
        raise ValueError(
            "Model output and class labels do not match."
        )

    return model, class_names


model, class_names = load_resources()

def preprocess_image(image):
    image = image.convert("RGB")
    image = image.resize((224, 224))

    image_array = np.asarray(
        image, dtype=np.float32
    ) / 255.0

    image_array = np.expand_dims(
        image_array, axis=0
    )

    return image_array


st.sidebar.title("Mudra Recognition")
page = st.sidebar.radio(
    "Navigation",
    ["Home", "Predict", "About"]
)

if page == "Home":

    st.title("Bharatanatyam Mudra Recognition")
    st.subheader("AI-Based Hand Gesture Classification")

    st.write("""
    This project uses a Convolutional Neural Network
    (CNN) to recognize five Bharatanatyam hand mudras
    from uploaded images.

    The system is designed as a prototype for
    AI-assisted classical dance learning.
    """)

    st.markdown("### Project Objectives")

    st.write("""
    - Recognize five Bharatanatyam mudra classes.
    - Classify hand gesture images using a CNN.
    - Display predicted mudra and confidence score.
    - Visualize probability scores across all classes.
    - Support dance learners with instant predictions.
    """)

    st.markdown("### System Workflow")

    st.info(
        "Upload Image → Image Preprocessing → "
        "CNN Classification → Predicted Mudra → "
        "Confidence & Class Probabilities"
    )

    st.markdown("### Supported Mudras")

    for i, name in enumerate(class_names, start=1):
        st.write(f"{i}. {name}")


elif page == "Predict":

    st.title("Mudra Prediction")
    st.write("Upload a Bharatanatyam hand mudra image.")

    uploaded_file = st.file_uploader(
        "Choose an image",
        type=["jpg", "jpeg", "png"]
    )

    if uploaded_file is not None:

        image = Image.open(uploaded_file).convert("RGB")

        col1, col2 = st.columns(2)

        with col1:
            st.image(
                image,
                caption="Uploaded Mudra Image",
                use_container_width=True
            )

        input_image = preprocess_image(image)

        probabilities = model.predict(
            input_image,
            verbose=0
        )[0]

        predicted_index = int(
            np.argmax(probabilities)
        )

        predicted_mudra = class_names[
            predicted_index
        ]

        confidence = float(
            probabilities[predicted_index]
        ) * 100

        with col2:
            st.subheader("Prediction Result")

            st.success(
                f"Predicted Mudra: {predicted_mudra}"
            )

            st.metric(
                "Prediction Confidence",
                f"{confidence:.2f}%"
            )

            if confidence < 60:
                st.warning(
                    "Low model confidence. Try a clearer "
                    "image with the complete hand visible."
                )

            st.caption(
                "Confidence is the model's output score, "
                "not a guarantee of correctness."
            )

        st.subheader("Probability Distribution")

        probability_df = pd.DataFrame({
            "Mudra": class_names,
            "Probability": probabilities
        })

        probability_df = probability_df.sort_values(
            "Probability",
            ascending=False
        )

        st.bar_chart(
            probability_df.set_index("Mudra")
        )

        probability_df["Probability (%)"] = (
            probability_df["Probability"] * 100
        ).round(2)

        st.dataframe(
            probability_df[
                ["Mudra", "Probability (%)"]
            ],
            hide_index=True,
            use_container_width=True
        )


elif page == "About":

    st.title("About the Project")

    st.subheader("Dataset")

    st.write("""
    Dataset: Mudra Dataset

    Source: Kaggle

    Dataset identifier:
    geethikanambiar/mudra-dataset

    The project uses five selected mudra classes.
    """)

    st.subheader("Model Architecture")

    st.write("""
    Model Type: Custom Convolutional Neural Network

    Input Image Size: 224 × 224 × 3

    Preprocessing:
    - RGB conversion
    - Image resizing
    - Pixel normalization to [0, 1]

    CNN Components:
    - Convolutional layers
    - Batch normalization
    - Max pooling
    - Global average pooling
    - Dense layers
    - Dropout
    - Softmax output
    """)

    st.subheader("Mudra Classes")

    st.write(", ".join(class_names))

    st.subheader("Model Information")

    st.write(
        "Output Classes:",
        len(class_names)
    )

    st.write(
        "Trainable Parameters:",
        f"{model.count_params():,}"
    )

    st.subheader("Limitations")

    st.write("""
    - Predictions may be incorrect for unfamiliar images.
    - Similar hand gestures can be confused.
    - Poor lighting and occlusion may reduce accuracy.
    - The system does not yet assess full dance technique.
    """)

    st.caption(
        "Certified AI & ML Engineer – Exit Examination Project"
    )
